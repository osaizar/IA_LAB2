package searchCustom;

public class CustomBreadthFirstSearch  extends CustomGraphSearch{

	public CustomBreadthFirstSearch(int maxDepth){
		super(false);  // Insertion at the end
	}
}
