package searchCustom;

public class CustomDepthFirstSearch extends CustomGraphSearch{
	
	public CustomDepthFirstSearch(int maxDepth){
		super(true);  // Insertion at the front
	}
}
