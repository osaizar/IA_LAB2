javac -classpath ../lib/* */*.java
